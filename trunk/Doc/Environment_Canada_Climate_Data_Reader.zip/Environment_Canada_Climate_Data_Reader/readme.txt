1. EnvironmentCanadaClimateData.exe is the program.
2. QuickGuide.pdf is the quick guide of the program.
3. Example folder has some example results.

Comments, bugs and more formats, please send me email: hawklorry@gmail.com.

Zhiqiang Yu
2013-12-12